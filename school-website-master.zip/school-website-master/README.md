# School Website Home Page
## [Demo](https://school-website-frontend.netlify.app/)
--------

I  have designed the school website front end design using html, css, bootstrap
## Technology Used

#### 1. `HTML`
#### 2. `CSS`
#### 3. `Bootstrap `


Step To Clone Repo

#### 1. Create a Github account.
#### 2. Open Command line interface in your pc
#### 3. Copy The Repo URL [https://github.com/pruthvi7384/school-website.git](https://github.com/pruthvi7384/school-website.git).
#### 4. After Clone This Repo index.html file open in browser`.

Site Screen Shorts 
-----

<img src="https://github.com/pruthvi7384/school-website/blob/master/Screenshot%20(591).png">


### THANK YOU !!!
